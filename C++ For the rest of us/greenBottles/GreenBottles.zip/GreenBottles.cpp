#include <iostream>

using namespace std;

int main()
{
    int greenBottles = 10;

    cout << "There were " << greenBottles << " Green Bottles" << endl;

    greenBottles--;

    cout << "There were " << greenBottles << " Green Bottles" << endl;

    return 0;
}